﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApp1
{
    class Program
    {
        const string tab = "    ";
        static void Main(string[] args)
        {
            StreamReader readmapname = new StreamReader("./"+Map(), Encoding.Unicode);

        }
        static void Start()
        {
            Console.WriteLine("Race!!!");
            Console.WriteLine(tab+"1. start game");
            Console.WriteLine(tab + "Q. quit");
        }
        static string Map()
        {
            StreamReader readmapname = new StreamReader("./name.txt", Encoding.Unicode);
            int mapcount = Convert.ToInt32(readmapname.ReadLine());
            string[] mapname = new string[mapcount];
            for (int i = 0; i < mapcount; i++)
            {
                mapname[i] = readmapname.ReadLine();
            }
            Console.Clear();
            Console.WriteLine("choose map:");
            for (int i = 0; i < mapcount; i++)
            {
                Console.WriteLine(tab + Convert.ToString(i) + ". " + mapname[i]);
            }
            int choosemap = Convert.ToInt32(Console.ReadLine());
            return mapname[choosemap];
        }
    }
}
